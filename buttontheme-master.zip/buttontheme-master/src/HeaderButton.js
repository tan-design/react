import React from 'react';

function HeaderButton(props) {
  return (
    <div>
      <button>Press me</button>
    </div>
  );
}

export default HeaderButton;